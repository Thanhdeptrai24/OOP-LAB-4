﻿#ifndef PREMIUM_H
#define PREMIUM_H

#include "Room.h"

// Lớp con Premium kế thừa từ Room
class Premium : public Room {
private:
    int serviceFee; // Phí dịch vụ
public:
    Premium(int nights, int serviceFee);
    int revenue() override;
};

#endif
