﻿#include "Room.h"

// Constructor của Room
// Input: nights - số đêm khách ở
// Output: Không có
// Algorithm: Gán giá trị nights được truyền vào cho thuộc tính nights
Room::Room(int nights) : nights(nights) {}
