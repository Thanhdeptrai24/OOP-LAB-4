﻿#ifndef DELUXE_H
#define DELUXE_H

#include "Room.h"

// Lớp con Deluxe kế thừa từ Room
class Deluxe : public Room {
private:
    int serviceFee;   // Phí dịch vụ
    int additionalFee; // Phí phục vụ
public:
    Deluxe(int nights, int serviceFee, int additionalFee);
    int revenue() override;
};

#endif
