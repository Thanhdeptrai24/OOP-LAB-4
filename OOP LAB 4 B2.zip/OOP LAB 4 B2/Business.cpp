﻿#include "Business.h"

// Constructor của Business
// Input: nights - số đêm khách ở
// Output: Không có
// Algorithm: Gán giá trị nights vào thuộc tính của lớp cha
Business::Business(int nights) : Room(nights) {}

// Tính doanh thu của phòng Business
// Input: Không có
// Output: Doanh thu = nights * 300000
// Algorithm: Sử dụng công thức doanh thu phòng Business
int Business::revenue() {
    return nights * 300000;
}
