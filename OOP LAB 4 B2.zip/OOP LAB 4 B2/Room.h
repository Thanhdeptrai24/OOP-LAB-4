#ifndef ROOM_H
#define ROOM_H

#include <string>
using namespace std;


class Room {
protected:
    int nights;     
public:
    Room(int nights);
    virtual ~Room() = default;
    virtual int revenue() = 0;
};

#endif
