﻿#include <iostream>
#include <vector>
#include "Deluxe.h"
#include "Premium.h"
#include "Business.h"
using namespace std;

int main() {
   
    Deluxe a(0, 200000, 100000);
    Deluxe b(0, 150000, 50000);
    Premium c(0, 100000);
    Premium d(1, 200000);
    Business e(5);

    
    vector<Room*> rooms = { &a, &b, &c, &d, &e };


    int maxRevenue = 0;
    Room* maxRoom = nullptr;

    for (Room* room : rooms) {
        int revenue = room->revenue();
        if (revenue > maxRevenue) {
            maxRevenue = revenue;
            maxRoom = room;
        }
    }
    string maxroom = "";
    if (maxRoom == &a || maxRoom == &b) {
        maxroom = "Deluxe";

    }
    else if (maxRoom == &c || maxRoom == &d) {
        maxroom = "Premium";
    }
    else {
        maxroom = "Business";
    }

   
    cout << "Doanh thu cao nhat la loai phong: " <<maxroom <<" doanh thu la: "<<maxRevenue << endl;

    return 0;
}
