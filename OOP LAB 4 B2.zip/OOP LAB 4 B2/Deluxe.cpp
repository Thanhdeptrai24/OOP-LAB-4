﻿#include "Deluxe.h"

// Constructor của Deluxe
// Input: nights - số đêm khách ở, serviceFee - phí dịch vụ, additionalFee - phí phục vụ
// Output: Không có
// Algorithm: Gán giá trị input vào các thuộc tính tương ứng
Deluxe::Deluxe(int nights, int serviceFee, int additionalFee)
    : Room(nights), serviceFee(serviceFee), additionalFee(additionalFee) {}

// Tính doanh thu của phòng Deluxe
// Input: Không có
// Output: Doanh thu = nights * 750000 + serviceFee + additionalFee
// Algorithm: Sử dụng công thức doanh thu phòng Deluxe
int Deluxe::revenue() {
    return nights * 750000 + serviceFee + additionalFee;
}
