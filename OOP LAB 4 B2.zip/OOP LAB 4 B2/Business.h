﻿#ifndef BUSINESS_H
#define BUSINESS_H

#include "Room.h"

// Lớp con Business kế thừa từ Room
class Business : public Room {
public:
    Business(int nights);
    int revenue() override;
};

#endif
