﻿#include "Premium.h"

// Constructor của Premium
// Input: nights - số đêm khách ở, serviceFee - phí dịch vụ
// Output: Không có
// Algorithm: Gán giá trị input vào các thuộc tính tương ứng
Premium::Premium(int nights, int serviceFee)
    : Room(nights), serviceFee(serviceFee) {}

// Tính doanh thu của phòng Premium
// Input: Không có
// Output: Doanh thu = nights * 500000 + serviceFee
// Algorithm: Sử dụng công thức doanh thu phòng Premium
int Premium::revenue() {
    return nights * 500000 + serviceFee;
}
