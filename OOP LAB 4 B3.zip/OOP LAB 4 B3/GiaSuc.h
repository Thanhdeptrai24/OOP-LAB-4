﻿#ifndef GIASUC_H
#define GIASUC_H

#include <string>
using namespace std;

class GiaSuc {
protected:
    int soLuong; // Số lượng gia súc hiện có
public:
    // Constructor
    // Input: soLuong (int) - số lượng gia súc ban đầu
    // Output: Không có
    // Thuật toán: Gán số lượng ban đầu cho thuộc tính `soLuong`.
    GiaSuc(int soLuong);

    // Phương thức ảo thuần túy phát tiếng kêu
    // Input: Không có
    // Output: Chuỗi mô tả tiếng kêu của gia súc
    // Thuật toán: Được các lớp con ghi đè để trả về tiếng kêu tương ứng.
    virtual string keu() = 0;

    // Phương thức ảo thuần túy sinh con
    // Input: Không có
    // Output: Số con được sinh ra (int)
    // Thuật toán: Được các lớp con ghi đè, tạo số lượng con sinh ra dựa trên số lượng hiện tại và một số ngẫu nhiên.
    virtual int sinhCon() = 0;

    // Phương thức ảo thuần túy cho sữa
    // Input: Không có
    // Output: Số lượng sữa thu được (int)
    // Thuật toán: Được các lớp con ghi đè, tính tổng lượng sữa dựa trên số lượng hiện tại và số ngẫu nhiên trong giới hạn.
    virtual int choSua() = 0;

    // Lấy số lượng gia súc hiện tại
    // Input: Không có
    // Output: Số lượng gia súc (int)
    // Thuật toán: Trả về giá trị thuộc tính `soLuong`.
    int getSoLuong();

    // Tăng số lượng gia súc
    // Input: soLuongMoi (int) - số lượng gia súc thêm vào
    // Output: Không có
    // Thuật toán: Cộng số lượng mới vào thuộc tính `soLuong`.
    void tangSoLuong(int soLuongMoi);
};

#endif
