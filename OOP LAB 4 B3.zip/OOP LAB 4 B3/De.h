#ifndef DE_H
#define DE_H

#include "GiaSuc.h"

class De : public GiaSuc {
public:
    De(int soLuong);
    string keu() override;
    int sinhCon() override;
    int choSua() override;
};

#endif
