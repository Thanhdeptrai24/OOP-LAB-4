﻿#include <iostream>
#include <vector>
#include "Bo.h"
#include "Cuu.h"
#include "De.h"
using namespace std;

int main() {
    vector<GiaSuc*> trangTrai;
    int x, y, z;
    cout << "So luong Bo, Cuu, De lan luot la: "<<endl;
    cin >> x >> y >> z;

    trangTrai.push_back(new Bo(x));
    trangTrai.push_back(new Cuu(y));
    trangTrai.push_back(new De(z));

  
    for (auto& giaSuc : trangTrai) {    
        
        cout << giaSuc->keu() << endl;
    }


    for (auto& giaSuc : trangTrai) {
        giaSuc->tangSoLuong(giaSuc->sinhCon());
    }


    int tongSua = 0;
    for (auto& giaSuc : trangTrai) {
        tongSua += giaSuc->choSua();
    }

    for (auto& giaSuc : trangTrai) {
        cout << "Tong so luong  " << typeid(*giaSuc).name() << ": " << giaSuc->getSoLuong() << endl;
    }
    cout << "Tong luong sua thu duoc " << tongSua << " lit" << endl;


    for (auto& giaSuc : trangTrai) {
        delete giaSuc;
    }

    return 0;
}
