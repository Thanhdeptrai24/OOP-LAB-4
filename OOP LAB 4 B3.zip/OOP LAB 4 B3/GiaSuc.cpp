#include "GiaSuc.h"

GiaSuc::GiaSuc(int soLuong) : soLuong(soLuong) {}

int GiaSuc::getSoLuong() {
    return soLuong;
}


void GiaSuc::tangSoLuong(int soLuongMoi) {
    soLuong += soLuongMoi;
}
