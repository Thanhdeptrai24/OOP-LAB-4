﻿#ifndef BO_H
#define BO_H

#include "GiaSuc.h"

class Bo : public GiaSuc {
public:
    // Constructor
    // Input: soLuong (int) - số lượng bò ban đầu
    // Output: Không có
    // Thuật toán: Gọi hàm khởi tạo của lớp cha để lưu số lượng bò ban đầu.
    Bo(int soLuong);

    // Tiếng kêu của bò
    // Input: Không có
    // Output: Chuỗi mô tả tiếng kêu
    // Thuật toán: Trả về chuỗi "Moo!" để biểu thị tiếng kêu của bò.
    string keu() override;

    // Số lượng con bò sinh ra
    // Input: Không có
    // Output: Số con được sinh ra (int)
    // Thuật toán: Sinh số ngẫu nhiên trong khoảng [0, số lượng bò hiện tại].
    int sinhCon() override;

    // Số lượng sữa bò cho
    // Input: Không có
    // Output: Số lượng sữa (int)
    // Thuật toán: Tính tổng sữa bằng cách nhân số lượng bò hiện tại với số ngẫu nhiên trong khoảng [0, 20].
    int choSua() override;
};

#endif
