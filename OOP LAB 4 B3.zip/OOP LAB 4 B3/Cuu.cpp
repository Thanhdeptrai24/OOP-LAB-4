﻿#include "Cuu.h"
#include <cstdlib>

Cuu::Cuu(int soLuong) : GiaSuc(soLuong) {}

string Cuu::keu() {
    return "Cuu keu : Baa!";
}

int Cuu::sinhCon() {
    return rand() % (soLuong + 1);
}

int Cuu::choSua() {
    return soLuong * (rand() % 6);
}
