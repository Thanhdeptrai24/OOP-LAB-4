#ifndef CUU_H
#define CUU_H

#include "GiaSuc.h"

class Cuu : public GiaSuc {
public:
    Cuu(int soLuong);
    string keu() override;
    int sinhCon() override;
    int choSua() override;
};

#endif
