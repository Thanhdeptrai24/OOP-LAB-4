#include "Bo.h"
#include <cstdlib>

Bo::Bo(int soLuong) : GiaSuc(soLuong) {}

string Bo::keu() {
    return "Bo keu : Moo!";
}

int Bo::sinhCon() {
    return rand() % (soLuong + 1);
}

int Bo::choSua() {
    return soLuong * (rand() % 21);
}
