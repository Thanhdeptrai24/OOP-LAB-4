#include "De.h"
#include <cstdlib>

De::De(int soLuong) : GiaSuc(soLuong) {}

string De::keu() {
    return "De keu: Mee!";
}

int De::sinhCon() {
    return rand() % (soLuong + 1);
}

int De::choSua() {
    return soLuong * (rand() % 11);
}
