﻿#ifndef NHANVIEN_H
#define NHANVIEN_H
#include <iomanip>
#include <string>
#include <iostream>
using namespace std;

// Lớp cơ sở NhanVien
class NhanVien {
protected:
    string maNV;
    string ten;
    int luongCB;

public:
    NhanVien(string ma = "", string ten = "", double luong = 0.0);

    virtual int TienThuong() = 0;

    virtual void Xuat();

    virtual ~NhanVien();
};

// Lớp dẫn xuất QuanLy
class QuanLy : public NhanVien {
private:
    double tyLeThuong;

public:
    QuanLy(string ma = "", string ten = "", double luong = 0.0, double tyLe = 0.0);

    int TienThuong() override;

    void Xuat() override;
};

// Lớp dẫn xuất KySu
class KySu : public NhanVien {
private:
    int soGioLamThem;

public:
    KySu(string ma = "", string ten = "", double luong = 0.0, int soGio = 0);

    int TienThuong() override;

    void Xuat() override;
};

#endif
