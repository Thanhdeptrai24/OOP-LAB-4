﻿#include "NhanVien.h"


int main() {
    // Nhập thông tin quản lý
    cout << "Nhap thong tin Quan Ly:\n";
    string maQL, tenQL;
    double luongCBQL, tyLeThuong;
    cout << "Ma NV: ";
    cin >> maQL;
    cout << "Ten: ";
    cin.ignore();
    getline(cin, tenQL);
    cout << "Luong co ban: ";
    cin >> luongCBQL;
    cout << "Ty le thuong: ";
    cin >> tyLeThuong;
    QuanLy ql(maQL, tenQL, luongCBQL, tyLeThuong);

    // Nhập thông tin kỹ sư
    cout << "\nNhap thong tin Ky Su:\n";
    string maKS, tenKS;
    double luongCBKS;
    int soGioLamThem;
    cout << "Ma NV: ";
    cin >> maKS;
    cout << "Ten: ";
    cin.ignore();
    getline(cin, tenKS);
    cout << "Luong co ban: ";
    cin >> luongCBKS;
    cout << "So gio lam them: ";
    cin >> soGioLamThem;
    KySu ks(maKS, tenKS, luongCBKS, soGioLamThem);

    // Xuất thông tin quản lý
    cout << "\nThong tin Quan Ly:\n";
    ql.Xuat();

    // Xuất thông tin kỹ sư
    cout << "\nThong tin Ky Su:\n";
    ks.Xuat();

    return 0;
}
