﻿#include "NhanVien.h"



// Constructor của NhanVien
// Input: mã nhân viên (ma - string), tên (ten - string), lương cơ bản (luong - double).
// Output: Tạo một đối tượng NhanVien với các thuộc tính được khởi tạo.
// Hướng giải thuật: Gán giá trị đầu vào cho các thuộc tính của lớp.
NhanVien::NhanVien(string ma, string ten, double luong)
    : maNV(ma), ten(ten), luongCB(luong) {}

// Destructor của NhanVien
// Input: Không có tham số.
// Output: Giải phóng tài nguyên (nếu cần).
// Hướng giải thuật: Được sử dụng tự động khi đối tượng bị hủy.
NhanVien::~NhanVien() {}

// Phương thức Xuat của NhanVien
// Input: Không có tham số.
// Output: Hiển thị thông tin mã nhân viên, tên và lương cơ bản ra màn hình.
// Hướng giải thuật: Sử dụng các thuộc tính của lớp và in ra console.
void NhanVien::Xuat() {
    cout << "Ma NV: " << maNV << "\n"
        << "Ten: " << ten << "\n"
        << "Luong co ban: " << luongCB << endl;
}

// Constructor của QuanLy
// Input: mã nhân viên (ma - string), tên (ten - string), lương cơ bản (luong - double), tỷ lệ thưởng (tyLe - double).
// Output: Tạo một đối tượng QuanLy với các thuộc tính được khởi tạo.
// Hướng giải thuật: Gọi constructor của lớp cơ sở để khởi tạo các thuộc tính chung,
// sau đó gán giá trị tỷ lệ thưởng cho thuộc tính của lớp QuanLy.
QuanLy::QuanLy(string ma, string ten, double luong, double tyLe)
    : NhanVien(ma, ten, luong), tyLeThuong(tyLe) {}

// Phương thức TienThuong của QuanLy
// Input: Không có tham số.
// Output: Trả về giá trị tiền thưởng (double), được tính bằng công thức `luongCB * tyLeThuong`.
// Hướng giải thuật: Lấy giá trị lương cơ bản nhân với tỷ lệ thưởng.
int QuanLy::TienThuong() {
    return luongCB * tyLeThuong;
}

// Phương thức Xuat của QuanLy
// Input: Không có tham số.
// Output: Hiển thị thông tin mã nhân viên, tên, lương cơ bản, tỷ lệ thưởng và tiền thưởng ra màn hình.
// Hướng giải thuật:
// - Gọi phương thức Xuat() từ lớp cơ sở để hiển thị thông tin chung.
// - Hiển thị thêm tỷ lệ thưởng và tiền thưởng bằng cách gọi TienThuong().
void QuanLy::Xuat() {
    NhanVien::Xuat();
    cout << "Ty le thuong: " << tyLeThuong << "\n"
        << "Tien thuong: " << TienThuong() << endl;
}

// Constructor của KySu
// Input: mã nhân viên (ma - string), tên (ten - string), lương cơ bản (luong - double), số giờ làm thêm (soGio - int).
// Output: Tạo một đối tượng KySu với các thuộc tính được khởi tạo.
// Hướng giải thuật: Gọi constructor của lớp cơ sở để khởi tạo các thuộc tính chung,
// sau đó gán giá trị số giờ làm thêm cho thuộc tính của lớp KySu.
KySu::KySu(string ma, string ten, double luong, int soGio)
    : NhanVien(ma, ten, luong), soGioLamThem(soGio) {}

// Phương thức TienThuong của KySu
// Input: Không có tham số.
// Output: Trả về giá trị tiền thưởng (double), được tính bằng công thức `soGioLamThem * 100000`.
// Hướng giải thuật: Lấy giá trị số giờ làm thêm nhân với 100,000.
int KySu::TienThuong() {
    return soGioLamThem * 100000;
}

// Phương thức Xuat của KySu
// Input: Không có tham số.
// Output: Hiển thị thông tin mã nhân viên, tên, lương cơ bản, số giờ làm thêm và tiền thưởng ra màn hình.
// Hướng giải thuật:
// - Gọi phương thức Xuat() từ lớp cơ sở để hiển thị thông tin chung.
// - Hiển thị thêm số giờ làm thêm và tiền thưởng bằng cách gọi TienThuong().
void KySu::Xuat() {
    NhanVien::Xuat();
    cout << "So gio lam them: " << soGioLamThem << "\n";
    cout<<  "Tiền thưởng: " << TienThuong() << endl;
   
}
